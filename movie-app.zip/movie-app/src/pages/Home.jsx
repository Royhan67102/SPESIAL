import Footer from "../components/Footer/Footer";  
import Navbar from "../components/Navbar/Navbar";
import Hero from "../components/Hero/Hero"; 
import Movies from "../components/Movies/Movies";
import Counter from "../components/counter";

function Home() {
  return (
    <div>
        <Navbar/>
        <main>
            <Hero/>
            <Movies/>
            <Counter/>
        </main>
        <footer>
            <Footer/>
        </footer>
    </div>
  );
}

export default Home;